Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/carousel-slider/

Thank you for your contribution.
