<?php
/**
 * Each module goes it own directory
 *
 * @package CarouselSlider/Modules
 */
