<?php
class Alti_ProtectUploads_Activator extends Alti_ProtectUploads
{

	public function run()
	{
	}
}
