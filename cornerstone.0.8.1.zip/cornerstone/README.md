# Cornerstone
Enhanced Content Management for WordPress

Cornerstone transforms WordPress into a full-fledged Content Management System.  Say *adios* to the hacks and tricks used to shoehorn your content into something that resembles a non-blog site and say hello to content management simplified.

[Learn more][home]

## Support
Found a bug or otherwise experiencing an issue with Cornerstone?  [Report the issue here][issue-report]

[issue-report]: https://github.com/archetyped/cornerstone/wiki/Support-&-Feedback "Report an issue"
[home]: http://archetyped.com/tools/cornerstone/ "Cornerstone home page"
