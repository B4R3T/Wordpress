<?php
class CNR_Field extends CNR_Field_Type {

}