/**
 * @package Cornerstone
 * @subpackage Admin
 * @author Archetyped
 */

(function ($) {

if ( CNR && CNR.extend ) CNR.extend('admin', {});
	
})(jQuery);